﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DLL.Models.Enums
{
    public enum OrderStatus
    {
        INLINE,
        COMPLETED,
        CANSELED,
    }
}
